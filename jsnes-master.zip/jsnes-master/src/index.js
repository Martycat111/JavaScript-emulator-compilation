module.exports = {
  Controller: require("./controller"),
  NES: require("./nes"),
};
